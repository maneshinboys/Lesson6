# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '740e32406f3008c4068b51f76508779c1717b8841a91beffbd908cbe377bb22df68e85b0d41a150e4df3974088f49b6b3133206bf3c3a796041c85cd4300438a'